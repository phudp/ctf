#!/bin/sh

env -i ./prospector
