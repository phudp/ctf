#!/bin/sh

env -i ./tape
